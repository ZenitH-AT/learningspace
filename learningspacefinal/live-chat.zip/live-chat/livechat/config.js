var config = {
	parentDomain : 'http://localhost:8080', 	//Host Domain (use Apache's http port)
	web_port : 8088,							//Port where app will be hosted; https://www.youtube.com/watch?v=_lPZjDL7ilU
	admin_url : '/adminURL',					//Choose a URL where admin panel can be accessed
	redis_port : 6379,							//Redis Port
	redis_hostname : "localhost", 				//Redis Hostname 
	admin_users : ['admin'], 					//Add usernames for different admins
	key : 'cGFzc3dvcmQ='						//Admin Password btoa hashed (Default = 'password')
};

module.exports = config;