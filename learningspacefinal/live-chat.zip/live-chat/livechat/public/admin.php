<link rel="stylesheet" href="http://localhost:8088/css/admin-live-chat.css">

<ul class="pages">
	<li class="chat page">
		<div class="container">
		</div>
		<div class="usersOnline">
			<h1>Admins Online</h1>
			<ul class="adminList" id="admins">
			</ul>
		</div>
	</li>
	<li class="login page">
		<div class="form">
			<h3 class="title">What's your nickname?</h3>
			<input class="usernameInput" type="text" maxlength="14" />
			<h3 class="title">Password</h3>
			<input class="passwordInput" type="password" maxlength="10" />
		</div>
	</li>
	<li class="error page" style="display: none">
		<div class="form">
			<h3 class="title">Reconnecting...</h3>
		</div>
	</li>
</ul>

<audio id="windowSound">
	<source src="/sounds/new_chat_window.mp3" type="audio/mpeg">
</audio>
<audio id="chatSound">
	<source src="/sounds/new_message.mp3" type="audio/mpeg">
</audio>
<audio id="pokeSound">
	<source src="/sounds/poke.mp3" type="audio/mpeg">
</audio>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://localhost:8088/socket.io/socket.io.js"></script>
<script src="http://localhost:8088/js/admin.js"></script>
