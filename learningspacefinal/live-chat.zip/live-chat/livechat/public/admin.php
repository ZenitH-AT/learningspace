<link rel="stylesheet" href="http://localhost:8088/css/admin-live-chat.css">

<ul class="pages">
	<li class="chat page">
		<div class="container">
		</div>
	</li>
	<li class="error page" style="display: none">
		<div class="form">
			<h3 class="title">Reconnecting...</h3>
		</div>
	</li>
</ul>

<audio id="windowSound">
	<source src="http://localhost:8088/sounds/new_chat_window.mp3" type="audio/mpeg">
</audio>
<audio id="chatSound">
	<source src="http://localhost:8088/sounds/new_message.mp3" type="audio/mpeg">
</audio>
<audio id="pokeSound">
	<source src="http://localhost:8088/sounds/poke.mp3" type="audio/mpeg">
</audio>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://localhost:8088/socket.io/socket.io.js"></script>
<script src="http://localhost:8088/js/admin.js"></script>
