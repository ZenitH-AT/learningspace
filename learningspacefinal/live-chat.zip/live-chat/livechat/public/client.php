<link rel="stylesheet" href="http://localhost:8088/css/client-live-chat.css">

<script type="text/javascript">
    var clientIDSession = '<?php echo "Student ID: " . $_SESSION["iduser"];?>';
	var clientNameSession = '<?php echo "Name: " . $_SESSION["firstname"] . " " . $_SESSION["lastname"];?>';
	var clientEmailSession = '<?php echo "Email: " . $_SESSION["email"];?>';
</script>

<div class="msg_box" style="right: 6%">
	<div class="msg_head">Live Chat</div>
	<div class="contentArea" style="display: none">
		<div class="formArea">
			<form class="inputFields">
				<input type="submit" class="submitBtn" value="Click to start live chat">
			</form>
		</div>
		<div class="chatArea" style="display: none">
			<div class="messages">
				<div class="msg_push_old"></div>
				<div class="msg_push_new"></div>
			</div>
			<div class='typing'></div>
			<textarea class="inputMessage" style="background: #c5cfe2;" rows="3" placeholder="Type here... Press enter to send."></textarea>
		</div>
	</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://localhost:8088/socket.io/socket.io.js"></script>
<script src="http://localhost:8088/js/client.js"></script>

