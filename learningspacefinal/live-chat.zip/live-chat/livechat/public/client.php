<link rel="stylesheet" href="http://localhost:8088/css/style.css">

<div class="msg_box" style="right: 6%">
	<div class="msg_head">Live Chat</div>
	<div class="contentArea" style="display: none">
		<div class="formArea">
			<div class="title">Please fill out this form</div>
			<form class="inputFields">
				<div class="inputContainer">
					<input class="nameInput" type="text" maxlength="20" pattern="^[a-zA-Z ]{3,}" placeholder=" * Name" required />
				</div>
				<div class="inputContainer">
					<input class="emailInput" type="email" placeholder=" * Email" required />
				</div>
				<div class="inputContainer">
					<input class="phoneInput" type="text" pattern="[0-9\(\)\-\+ ]{8,15}" title="Enter a valid Phone Number" placeholder=" * Phone Number" required />
				</div>
				<input type="submit" class="submitBtn">
			</form>
		</div>
		<div class="chatArea" style="display: none">
			<div class="messages">
				<div class="msg_push_old"></div>
				<div class="msg_push_new"></div>
			</div>
			<div class='typing'></div>
			<input class="inputMessage" rows="1" placeholder="Type here..."></input>
		</div>
	</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://localhost:8088/socket.io/socket.io.js"></script>
<script src="http://localhost:8088/js/client.js"></script>

