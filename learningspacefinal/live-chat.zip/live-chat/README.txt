Step 1: Download and install the following:

Node.js: https://nodejs.org/en/download/
Redis for Windows: https://github.com/MicrosoftArchive/redis/releases
Git: https://git-scm.com/download/win

NOTE: The redis server (NoSQL DB that stores live chats) is started and stopped in the Services tab in Task Manager. To clear the database, you must go to 'C:\Program Files\Redis' and open 'redis-cli.exe', then type 'FLUSHALL'.



Step 2: Replace httpd.conf and php.ini with the ones included. This enables:

- Forwarding communications from port 8088 (Node.js server) to 8080 (Apache server)
- PHP include for URLs

NOTE: You MUST use port 8088 for the Node.js server to work, as this port number is mentioned in many areas (I was too lazy to use a global variable, this may change later). The same may apply for using port 8080 for the Apache server but I have not tested this yet.




Step 3: To add to the page, simply paste the following code:

On client side: include 'http://localhost:8088/client.php';
On admin side: include 'http://localhost:8088/admin.php';

NOTE: The client and admin cannot be included on the same page to test (it just won't work; they must be on separate pages). The live chat also doesn't work on Firefox, yet.

You can test the live chat system with the included HTML files as well.





References:
https://www.cronj.com/blog/build-a-live-chat-for-customer-support/
https://stackoverflow.com/questions/46151327/keep-getting-socket-io-eio-3transport-pollingt-lvm1sgo-404-errors-when-i-de
https://stackoverflow.com/questions/31919485/socket-io-ignoring-url-path-seems-to-cause-polling-get-404-error
